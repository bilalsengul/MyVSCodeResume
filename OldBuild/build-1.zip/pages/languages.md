# 💬 Languages
**English**: B2
**Turkish**: Native