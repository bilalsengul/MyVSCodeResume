# 👨‍🎓 Education

**Bachelor of Science (B.S.) in Computer Engineering**   @ [ Sakarya University](https://cs.sakarya.edu.tr/) _(September 2017 – June 2021)_
Sakarya, Turkey
September 2017 – June 2021
● During his university academic life, he has been awarded 2 semesters as an honor student and 3 semesters as a high honor
student.
